# 构建标记：本包由 build.py 生成
BUILD_MODE = "combined"
